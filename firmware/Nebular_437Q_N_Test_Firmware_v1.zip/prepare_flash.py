#!/usr/bin/env python3
"""Offline application sector plan and recovery files. Never opens hardware."""
import argparse,hashlib,json,struct,zlib
from pathlib import Path
HERE=Path(__file__).resolve().parent

def sha(data): return hashlib.sha256(data).hexdigest()
def prepare(before,firm,meta):
 if len(before)!=0x80000: raise ValueError('Expected a complete 512 KiB same-tag backup')
 if before[0x7e000:0x7e05c].hex()!=meta['accepted_product_record']:
  raise ValueError('Factory product record differs from the captured 437 revision')
 if not (len(firm)==meta['bytes'] and len(firm)<0x20000 and sha(firm)==meta['sha256'] and
         firm[8:12]==b'KNLT' and struct.unpack_from('<I',firm,24)[0]==len(firm) and
         struct.unpack_from('<I',firm,len(firm)-4)[0]==(zlib.crc32(firm[:-4])^0xffffffff)):
  raise ValueError('Firmware hash, size, header or checksum invalid')
 padded=firm+b'\xff'*(-len(firm)%4096)
 after=padded+before[len(padded):]
 assert after[0x20000:]==before[0x20000:]
 order=[off for off in list(range(4096,len(padded),4096))+[0]
        if before[off:off+4096]!=after[off:off+4096]]
 return after,padded,order

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--before',type=Path,required=True,help='Verified full backup of the physical tag to be programmed')
 p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 # Works both inside the source tree and the flattened download package.
 root=HERE/'dist' if (HERE/'dist/manifest.json').exists() else HERE
 meta=json.loads((root/'manifest.json').read_text());firm=(root/meta['firmware']).read_bytes()
 before=a.before.read_bytes();after,padded,order=prepare(before,firm,meta)
 a.output.mkdir(parents=True,exist_ok=False)
 (a.output/'application-padded.bin').write_bytes(padded)
 (a.output/'expected-full-flash.bin').write_bytes(after)
 (a.output/'recovery-application.bin').write_bytes(before[:len(padded)])
 plan=dict(hardware_access=False,backup_sha256=sha(before),firmware_sha256=sha(firm),
           expected_full_flash_sha256=sha(after),write_start=0,write_bytes=len(padded),
           sectors_in_write_order=order,sector_size=4096,preserve_start=len(padded),preserve_end=0x80000,
           recovery='Restore recovery-application.bin at0 only if upper flash is unchanged; otherwise restore YOUR same-tag full backup',
           requirements=['Verify two full same-tag reads match before programming','Preserve factory/calibration/identity sectors; do not mass-erase','Verify each written sector and then the complete flash against expected-full-flash.bin','These files contain per-tag data; keep private'])
 (a.output/'flash-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan,indent=2))
if __name__=='__main__':main()
