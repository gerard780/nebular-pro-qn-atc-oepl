#!/usr/bin/env python3
"""Create the AP profile and four-color orientation target (requires Pillow)."""
from pathlib import Path
import json,shutil
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent;out=P/'dist'
colors={'white':[255,255,255],'black':[0,0,0],'red':[255,0,0],'yellow':[255,255,0]}
profile=dict(version=1,name='Nebular Pro-437Q-N HS9118 (experimental v1)',width=480,height=176,rotatebuffer=1,bpp=2,colortable=colors,perceptual=colors,shortlut=0,contentids=[22,23],template={'22':{}},options=[])
(out/'74.json').write_text(json.dumps(profile,indent=2)+'\n')
img=Image.new('RGB',(480,176),'white');d=ImageDraw.Draw(img)
f=ImageFont.load_default(size=20);small=ImageFont.load_default(size=12)
d.rectangle((0,0,479,175),outline='black',width=2)
d.text((10,7),'437Q-N / HS9118 / TEST V1',font=f,fill='black')
d.text((10,33),'480 x 176 | WHITE BLACK RED YELLOW',font=small,fill='black')
for i,(color,label) in enumerate(zip(colors,['WHITE','BLACK','RED','YELLOW'])):
 x=4+i*118;r=x+117;ink='white' if color=='black' else 'black'
 d.rectangle((x,54,r,143),fill=color,outline='black')
 d.text((x+7,63),label,font=small,fill=ink)
 d.rectangle((x+10,93,r-10,133),outline=ink,width=2)
 d.text((x+20,104),str(i+1),font=f,fill=ink)
d.text((10,155),'TOP LEFT   >   1  2  3  4   >   BOTTOM RIGHT',font=small,fill='black')
img.save(out/'test-pattern.png');img.save(out/'test-pattern.jpg',quality=100,subsampling=0)
print('Generated AP profile and asymmetric four-color test image.')
