#include <assert.h>
#include <stdio.h>
#include <string.h>
#define NEBULAR_ADAPTER_HOST
#include "adapter.c"
#include "test_oracles.inc"
uint8_t host_pb,host_pd,host_pa=2,host_temp=24,host_config[176];
uint32_t host_tick=0xffff0000u,host_outer;
static uint8_t flash[0x80000],saved[176],expected_wave[2][535],sent[22000];
static unsigned starts,ends,saves,frames,frame_bytes,cmd=0xff,n,errors,raw_two;
static unsigned init_active,init_index,init_case,prep_active,prep_index;
static const unsigned prep_commands[7]={0x4d,0xae,0xbd,0xb0,0xad,0xb6,0xba};
static const uint8_t prep_values[7]={0x78,0xaf,0x80,0x13,0x17,0x0f,0x2a};
void host_flash(uint32_t a,uint32_t count,void *p) {
 assert((a==0x7e000 && count==92) || (a>=0x40000 && a+count<=0x73000));
 memcpy(p,flash+a,count);
}
void host_load(void) { memcpy(host_config,saved,176); }
void host_set_panel(unsigned preset) {
 assert(preset==0 || preset==17);
 host_config[12]=preset ? 0x74 : 0xfa;host_config[13]=0;
 host_config[15]=preset;host_config[16]=0;host_config[17]=preset ? 5 : 0;host_config[18]=0;
 host_config[22]=preset ? 0xe0 : 0;host_config[23]=!!preset;
 host_config[24]=preset ? 176 : 0;host_config[25]=0;
}
void host_save(void) { memcpy(saved,host_config,176);++saves; }
void host_start(unsigned x) { assert(x==1);++starts; }
void host_end(void) { ++ends;adapter_refresh(); }
void host_log(const char *s) { (void)s;++errors; }
static void finish_command(void) {
 unsigned phase=(frames ? frames-1 : 0)%2;
 if(prep_active) {
  assert(prep_index<7 && cmd==prep_commands[prep_index] && n==1 && sent[0]==prep_values[prep_index]);
  if(++prep_index==7) prep_active=0;
 }
 if(init_active) {
  const struct expected_register *e=&expected_init[init_case][init_index];
  assert(cmd==e->command && n==e->count && memcmp(sent,e->data,n)==0);
  if(++init_index==15) init_active=0;
 }
 if(cmd==0x20) { assert(n==535 && memcmp(sent,expected_wave[phase],535)==0); }
 if(cmd==0x10) {
  unsigned i;uint8_t expected=phase ? (raw_two ? 0x45 : 0x44) : (raw_two ? 0x5e : 0x55);
  assert(n==21120);
  for(i=0;i<n;++i) assert(sent[i]==expected);
  frame_bytes+=n;
 }
}
void host_command(unsigned c) {
 finish_command();cmd=c;n=0;
 if(c==0x4d) { prep_active=1;prep_index=0; }
 if(c==0) { assert(!prep_active);init_active=1;init_index=0;init_case=S->band*2+frames%2; }
 if(c==0x20) ++frames;
}
void host_data(unsigned d) { assert(n<sizeof sent);sent[n++]=(uint8_t)d; }
void host_delay(unsigned us) { host_tick+=us*16; }
static void fixture(unsigned two) {
 unsigned size=10560*(two+1);
 raw_two=two;memcpy(flash+0x7e000,product_records[0],92);host_set_panel(17);
 memset(flash+0x40000,0,21);memcpy(flash+0x4000c,&size,4);flash[0x40010]=two ? 0x21 : 0x20;
 memset(flash+0x40015,0x55,10560);memset(flash+0x40015+10560,0x33,10560);
 memset(S,0,sizeof(*S));cmd=0xff;n=0;frames=0;frame_bytes=0;host_pa=2;
 init_active=prep_active=0;
}
static void load_expected(unsigned band,const char *directory) {
 char name[1024];unsigned phase;
 for(phase=0;phase<2;++phase) {
  FILE *f;snprintf(name,sizeof name,"%s/band-%02u-mode-%u.bin",directory,band,phase+1);
  f=fopen(name,"rb");assert(f);assert(fread(expected_wave[phase],1,535,f)==535);fclose(f);
 }
}
static void complete(void) {
 unsigned i;
 for(i=0;i<20;++i) { host_tick+=320000;if(adapter_ready()) break; }
 finish_command();cmd=0xff;n=0;
 assert(i<20 && S->panel.state==NEBULAR_DONE && !S->failed && frames==2);
 assert(frame_bytes==42240 && (host_pb&0x20) && !init_active && !prep_active);
}
int main(int argc,char **argv) {
 static const int temps[4]={15,20,25,30};
 unsigned band,two,i,old,old_saves,checks=0;
 assert(argc==2);
 memcpy(flash+0x7e000,product_records[0],92);assert(detect_model()==0);
 for(i=0;i<176;++i) saved[i]=(uint8_t)(i*7+3);
 old_saves=saves;nebular_boot();assert(saves==old_saves+1 && saved[12]==0x74);
 for(i=47;i<102;++i) assert(saved[i]==(uint8_t)(i*7+3));
 nebular_boot();assert(saves==old_saves+1);
 for(i=0;i<92;++i) {
  flash[0x7e000+i]^=1;assert(detect_model()==2);nebular_boot();assert(saved[12]==0xfa && saved[17]==0);
  flash[0x7e000+i]^=1;
 }
 /* Every captured bank, including runtime-disabled extremes: two full passes,
    source-derived TC32 initialization oracle, preparation, and full pixel stream. */
 for(band=0;band<8;++band) for(two=0;two<2;++two) {
  fixture(two);load_expected(band,argv[1]);S->magic=MAGIC;S->address=0x40015;
  S->two_planes=two;S->band=band;S->cache_index=~0u;S->last_tick=host_tick;
  adapter_refresh();complete();++checks;
 }
 /* The image hook must select bands correctly and enforce the ambient gate. */
 for(band=3;band<7;++band) for(two=0;two<2;++two) {
  fixture(two);host_temp=temps[band-3];load_expected(band,argv[1]);old=starts;
  adapter_image(0x40000,0);assert(starts==old+1 && S->band==band && S->model==0);
  adapter_image(0x40000,0);assert(starts==old+1);complete();++checks;
 }
 for(i=0;i<256;++i) {
  int t=(int8_t)i;fixture(1);host_temp=i;old=starts;adapter_image(0x40000,0);
  assert(starts==old+(t>=15 && t<=30));
  if(t>=15 && t<=30) assert(S->band==(t==15 ? 3 : t<=20 ? 4 : t<=25 ? 5 : 6));
 }
 /* All 84,480 asymmetric pixels must preserve native row orientation. */
 fixture(1);S->address=0x40015;S->two_planes=1;S->cache_index=~0u;
 for(i=0;i<10560;++i) { flash[0x40015+i]=(uint8_t)(i*37+(i>>3));flash[0x40015+10560+i]=(uint8_t)(i*71+(i>>5)); }
 for(i=0;i<84480;++i) {
  unsigned mapped=(479-i/176)*176+i%176,mask=0x80u>>(mapped&7);
  static const unsigned codes[4]={5,4,13,9};
  unsigned color=!!(flash[0x40015+mapped/8]&mask)+2*!!(flash[0x40015+10560+mapped/8]&mask);
  assert(pixel(S,i)==codes[color]);
 }
 host_temp=24;old=starts;
 fixture(1);flash[0x40010]=0x30;adapter_image(0x40000,0);assert(starts==old);
 fixture(1);flash[0x4000c]=1;adapter_image(0x40000,0);assert(starts==old);
 fixture(1);host_config[12]^=1;adapter_image(0x40000,0);assert(starts==old);
 fixture(1);host_config[22]^=1;adapter_image(0x40000,0);assert(starts==old);
 fixture(1);flash[0x7e000]^=1;adapter_image(0x40000,0);assert(starts==old);
 fixture(1);adapter_image(0x3ffff,0);adapter_image(0x72fff,0);assert(starts==old);
 /* Each BUSY timeout must cut panel power, including a wrap-safe long refresh. */
 for(i=NEBULAR_RESET_WAIT;i<=NEBULAR_OFF_WAIT;++i) {
  unsigned ms=i==NEBULAR_RESET_WAIT || i==NEBULAR_OFF_WAIT ? 401 : i==NEBULAR_POWER_WAIT || i==NEBULAR_INIT_WAIT ? 2001 : 200001;
  fixture(1);S->magic=MAGIC;S->last_tick=host_tick;S->panel.io=&io;S->panel.context=S;
  S->panel.state=(enum nebular_state)i;S->panel.since=0;host_pa=0;host_pb&=(uint8_t)~0x20;
  host_tick+=16000*ms;assert(adapter_ready() && S->panel.state==NEBULAR_ERROR && (host_pb&0x20));
 }
 fixture(1);S->magic=MAGIC;S->failed=1;S->panel.io=&io;S->panel.context=S;
 S->panel.state=NEBULAR_DONE;assert(adapter_ready() && S->panel.state==NEBULAR_ERROR && (host_pb&0x20));
 S->last_tick=0xfffffff0u;S->milliseconds=100;S->remainder=0;host_tick=15984;assert(millis(S)==101);
 printf("PASS: %u paired RAW1/RAW2 refreshes, all16 waveform/initialization traces, 437 preparation, every asymmetric pixel, all92 product mutations, boot identity preservation, all256 temperature values, image rejection, all5 BUSY timeouts, stream-fault power cut and timer wrap. Host state %zu bytes.\n",checks,sizeof(*S));
 return 0;
}
