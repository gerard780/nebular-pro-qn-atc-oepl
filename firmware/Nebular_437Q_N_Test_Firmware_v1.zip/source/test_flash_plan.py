"""No-hardware checks for installation plan, preservation and recovery."""
from pathlib import Path
import json
from prepare_flash import prepare
P=Path(__file__).resolve().parent
meta=json.loads((P/'dist/manifest.json').read_text());firm=(P/'dist'/meta['firmware']).read_bytes()
before=bytearray(bytes(range(256))*2048)
before[0x7e000:0x7e05c]=bytes.fromhex(meta['accepted_product_record'])
after,padded,order=prepare(bytes(before),firm,meta)
assert len(after)==len(before)==524288 and after[:len(firm)]==firm
assert after[len(padded):]==before[len(padded):] and after[0x20000:]==before[0x20000:]
assert order[-1]==0 and all(i%4096==0 and i<0x20000 for i in order)
# Replay the specified plan; then recover those same sectors.
live=bytearray(before)
for off in order: live[off:off+4096]=after[off:off+4096]
assert live==after
for off in order: live[off:off+4096]=before[off:off+4096]
assert live==before
for bad_before,bad_firm in [(bytes(before[:-1]),firm),(bytes(before[:0x7e000])+b'\0'+bytes(before[0x7e001:]),firm),(bytes(before),firm[:-1]),(bytes(before),bytes([firm[0]^1])+firm[1:])]:
 try: prepare(bad_before,bad_firm,meta)
 except ValueError: pass
 else: raise AssertionError('Invalid backup/image accepted')
print('PASS: image integrity, exact revision guard, sector0 last, complete upper-flash preservation, application restoration and invalid inputs.')
