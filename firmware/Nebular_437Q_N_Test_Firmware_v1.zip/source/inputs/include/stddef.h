#ifndef STOCK_TC32_STDDEF_H
#define STOCK_TC32_STDDEF_H
typedef __SIZE_TYPE__ size_t;
#endif
