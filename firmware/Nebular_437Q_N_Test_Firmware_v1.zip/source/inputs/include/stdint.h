/* Minimal types for the available freestanding TC32 GCC (32-bit int/pointer).
   Use the platform's standard headers when integrating into another toolchain. */
#ifndef STOCK_TC32_STDINT_H
#define STOCK_TC32_STDINT_H
typedef unsigned char uint8_t;
typedef signed char int8_t;
typedef unsigned short uint16_t;
typedef signed short int16_t;
typedef unsigned int uint32_t;
typedef signed int int32_t;
typedef char stock_assert_u32[(sizeof(uint32_t)==4)?1:-1];
#endif
