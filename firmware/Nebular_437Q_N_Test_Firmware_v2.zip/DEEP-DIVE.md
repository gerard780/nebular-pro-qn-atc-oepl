# October 8: deeper 437 firmware analysis and test firmware v2

The factory dump exposes a complete display lifecycle. Comparing it with the experimental adapter identified a misplaced 20 ms reset pause and a missing pre-power-off command. Test firmware v2 corrects those differences, adjusts the power-on settling delay, and adds the stock delay after power-off BUSY release. It remains physically untested.

The investigation began at 12:46:12 UTC on October 8. It uses the existing pinned archive capture, without connecting to hardware. The source SHA256 is `d7b1b7220a8c8872866d77e1220a0e72666e4b3a8db31c3c880717fc0ee833ae`; archive commit `716d369dd4c8b1d1877ce4bf777423de3a84bac9`.

## Recovered control flow

Addresses below are even instruction addresses. Stored callback pointers have bit zero set. The common callback table starts at flash `0x39ae0`; the kind-indexed preparation table starts at `0x39ba8`, and kind 19 points to `0x3bf28`.

| Operation | Stock entry | Source-checked result |
|---|---|---|
| Classify driver 43 | `0x3b540` | Internal kind 19, category 40 |
| Enable panel power | `0x3a410` | Active-low PB5, then 1,000 µs |
| Reset | `0x3a444` | PD4 high 2 ms, low 2 ms, high 20 ms, low 2 ms, high 2 ms |
| Read panel temperature | `0x3b780` | `41 00`, `40`, BUSY wait, two response bytes |
| Prepare kind 19 | `0x3bf28` via `0x3b820` | Temperature read followed by `4d78 aeaf bd80 b013 ad17 b60f ba2a` |
| Start first image transfer | `0x3bfe0` | Command `10` |
| Start second image transfer | `0x3c00c` | Also command `10` for kind 19 |
| Refresh | `0x3c310` | `04`, 1 ms, BUSY wait, `12 00`, 10 ms, BUSY read; phase becomes 2 |
| Normal shutdown, phase 2 | `0x3dc3c` | `00 27 a9`, `02 00`, BUSY wait, 1 ms, `07 a5`; phase becomes 0 |

The v1 adapter put 20 ms in each low reset pulse. The stock code clearly puts its single 20 ms pause in the middle high interval. The v1 adapter also sent `02 00` directly after refresh. v2 adds `00 27 a9` first and delays 1 ms after observing power-off ready, including when BUSY releases late. GPIO supply cutoff after sleep remains an adapter operation.

Shutdown is state-dependent. A phase-1 path prepares additional registers and powers on before shutdown. The emitted v2 shutdown follows phase 2 after an ordinary completed refresh; this work does not claim equivalence to every stock shutdown state.

## Temperature and waveform selection

All **65,536 possible two-byte sensor responses** were passed through the stock temperature routine. RAM offset 11 always receives the first byte unchanged; the second-byte fraction is discarded. The waveform selector later interprets that RAM value as signed 8-bit temperature. These are simulated sensor responses, not measurements.

The waveform selector at `0x2da0c` receives temperature in r0, destination in r1, and mode in r2. It checks the 12 KiB package CRC, copies a 392-byte header, scales temperature by 100, and compares signed descriptor bounds. The exact rule is **lower < temperature <= upper**. Mode 1 and mode 2 read distinct 552-byte records. Both record address and length are decoded from the real header by the stock instructions.

**510 stock selector executions** cover every integer temperature −127 through 127 and both modes. Each selected record matches the exact captured waveform bytes. Tests use configuration flag value 1 to select the normal bank-search path. CRC calculation and flash reads are explicit simulator boundaries; the underlying CRC routine and hardware flash driver are not interpreted. The table’s −128/127 endpoints are format sentinels, not proven panel operating limits. The lower-exclusive −128 endpoint has no match among the eight captured bands; behavior involving descriptors outside the loaded header was not characterized.

The selector-1 SPI read branch uses indirect functions from flash `0x11000`. The first response read starts at `0x3aec4`, and the continuation starts at `0x3b010`. v2 continues to use the existing ATC software-SPI write path and MCU temperature reading with a 15–30°C gate. A successful simulated sensor decode does not validate a physical SPI read implementation.

## Validation and limits

`lifecycle_vm.py` checks the instruction bytes and PC-relative literals against the pinned 512 KiB dump for every executed instruction. Only explicitly modeled peripheral/RAM regions and named external boundaries are accessible. BUSY is modeled ready for stock lifecycle traces; sensor bytes are supplied by the tests. No arbitrary firmware or device I/O runs.

The v2 host lifecycle tests derive independent expected events from those stock traces. Power/reset and normal shutdown match, including both immediate and delayed power-off BUSY release. The existing 24 paired RAW1/RAW2 cases, all 16 initialization traces, 84,480 asymmetric pixel checks, 92 factory-record mutations, 256 runtime temperature values, five BUSY timeout paths, stream-error power cutoff and timer wrap also pass. Binary header/CRC, integration hooks, memory limits and application-only flash/recovery planning are checked.

Physical boot, radio integration, panel wiring, SPI timing, pixel orientation and the visible refresh remain unverified. MCU temperature can differ from panel temperature. The adapter returns completion on either success or a panel error to release ATC’s wait; therefore an AP acknowledgment cannot prove a screen update. Check the screen and UART diagnostics when testing. The factory waveform is retained; no optical behavior has been inferred from waveform bytes alone.

The binary is 123,204 bytes, SHA256 `686702649d7f4d181c5e5d99972a7932231577ace95417973c9c9d70d6a0fcf2`. v1 remains unchanged. See the v2 package README for same-tag backups, application-only wired installation, upper-flash preservation and recovery. No device was programmed during this work.

## Reproduce from this workspace

Run from `research/esl/nebular-pro-437q-n`:

```sh
python3 deep-dive-20261008/lifecycle_vm.py
python3 deep-dive-20261008/check_temperature.py
python3 deep-dive-20261008/check_wave_selector.py
python3 test-firmware-v2/build.py
python3 test-firmware-v2/verify_image.py
python3 test-firmware-v2/test_flash_plan.py
```

The research scripts use the retained dump, annotated disassembly, original initializer interpreter and extracted records in this directory. `peek.py` displays bounded address ranges. `source-excerpts.asm` retains relevant disassembly including raw instruction bytes. The firmware download includes the pinned source inputs and captured lifecycle oracle; its build is independent of the research interpreter. See `verification.json` and the report JSON files for machine-readable results.
