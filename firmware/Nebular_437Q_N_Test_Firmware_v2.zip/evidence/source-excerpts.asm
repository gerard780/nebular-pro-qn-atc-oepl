   2da0c:	65f0      	tpush	{r4, r5, r6, r7, lr}
   2da0e:	0657      	tmov	r7, sl
   2da10:	0646      	tmov	r6, r8
   2da12:	64c0      	tpush	{r6, r7}
   2da14:	0688      	tmov	r8, r1
   2da16:	f606      	tshftls	r6, r0, #24
   2da18:	e636      	tasrs	r6, r6, #24
   2da1a:	f617      	tshftls	r7, r2, #24
   2da1c:	fe3f      	tshftrs	r7, r7, #24
   2da1e:	0c3c      	tloadr	r4, [pc, #240]	; (0x2db10) ; LITERAL=0x00842ec0
   2da20:	5823      	tloadr	r3, [r4, #0]
   2da22:	481a      	tloadrb	r2, [r3, #0]
   2da24:	4859      	tloadrb	r1, [r3, #1]
   2da26:	f209      	tshftls	r1, r1, #8
   2da28:	0311      	tors	r1, r2
   2da2a:	489a      	tloadrb	r2, [r3, #2]
   2da2c:	f412      	tshftls	r2, r2, #16
   2da2e:	0311      	tors	r1, r2
   2da30:	48db      	tloadrb	r3, [r3, #3]
   2da32:	f61b      	tshftls	r3, r3, #24
   2da34:	0319      	tors	r1, r3
   2da36:	b102      	tadds	r1, #2
   2da38:	0836      	tloadr	r0, [pc, #216]	; (0x2db14) ; LITERAL=0x00001d0f
   2da3a:	0a37      	tloadr	r2, [pc, #220]	; (0x2db18) ; LITERAL=0x00002ffe
   2da3c:	97ff 9c12 	tjl	0x2d264
   2da40:	ec05      	tadds	r5, r0, #0
   2da42:	5823      	tloadr	r3, [r4, #0]
   2da44:	481a      	tloadrb	r2, [r3, #0]
   2da46:	4858      	tloadrb	r0, [r3, #1]
   2da48:	f200      	tshftls	r0, r0, #8
   2da4a:	0310      	tors	r0, r2
   2da4c:	489a      	tloadrb	r2, [r3, #2]
   2da4e:	f412      	tshftls	r2, r2, #16
   2da50:	0310      	tors	r0, r2
   2da52:	48db      	tloadrb	r3, [r3, #3]
   2da54:	f61b      	tshftls	r3, r3, #24
   2da56:	0318      	tors	r0, r3
   2da58:	0c30      	tloadr	r4, [pc, #192]	; (0x2db1c) ; LITERAL=0x008471dc
   2da5a:	ec21      	tadds	r1, r4, #0
   2da5c:	a2c4      	tmovs	r2, #196	; 0xc4
   2da5e:	f052      	tshftls	r2, r2, #1
   2da60:	9003 9906 	tjl	0x30c70
   2da64:	2823      	tloadrh	r3, [r4, #0]
   2da66:	02ab      	tcmp	r3, r5
   2da68:	c023      	tjeq	0x2dab2
   2da6a:	a203      	tmovs	r2, #3
   2da6c:	a344      	tmovs	r3, #68	; 0x44
   2da6e:	092c      	tloadr	r1, [pc, #176]	; (0x2db20) ; LITERAL=0x00842e68
   2da70:	1ccb      	tloadrb	r3, [r1, r3]
   2da72:	0013      	tands	r3, r2
   2da74:	c02d      	tjeq	0x2dad2
   2da76:	a001      	tmovs	r0, #1
   2da78:	ab02      	tcmp	r3, #2
   2da7a:	c016      	tjeq	0x2daaa
   2da7c:	a364      	tmovs	r3, #100	; 0x64
   2da7e:	035e      	tmuls	r6, r3
   2da80:	a300      	tmovs	r3, #0
   2da82:	f09a      	tshftls	r2, r3, #2
   2da84:	e8d2      	tadds	r2, r2, r3
   2da86:	f092      	tshftls	r2, r2, #2
   2da88:	e8a2      	tadds	r2, r4, r2
   2da8a:	ec11      	tadds	r1, r2, #0
   2da8c:	b15c      	tadds	r1, #92	; 0x5c
   2da8e:	a502      	tmovs	r5, #2
   2da90:	1f49      	tloadrsh	r1, [r1, r5]
   2da92:	02b1      	tcmp	r1, r6
   2da94:	ca05      	tjge	0x2daa2
   2da96:	ec11      	tadds	r1, r2, #0
   2da98:	b160      	tadds	r1, #96	; 0x60
   2da9a:	a500      	tmovs	r5, #0
   2da9c:	1f48      	tloadrsh	r0, [r1, r5]
   2da9e:	02b0      	tcmp	r0, r6
   2daa0:	ca0d      	tjge	0x2dabe
   2daa2:	b301      	tadds	r3, #1
   2daa4:	ab14      	tcmp	r3, #20
   2daa6:	c1ec      	tjne	0x2da82
   2daa8:	a000      	tmovs	r0, #0
   2daaa:	6c0c      	tpop	{r2, r3}
   2daac:	0690      	tmov	r8, r2
   2daae:	069a      	tmov	sl, r3
   2dab0:	6df0      	tpop	{r4, r5, r6, r7, pc}
   2dab2:	a344      	tmovs	r3, #68	; 0x44
   2dab4:	0a1a      	tloadr	r2, [pc, #104]	; (0x2db20) ; LITERAL=0x00842e68
   2dab6:	1cd3      	tloadrb	r3, [r2, r3]
   2dab8:	a203      	tmovs	r2, #3
   2daba:	0013      	tands	r3, r2
   2dabc:	87db      	tj	0x2da76
   2dabe:	af01      	tcmp	r7, #1
   2dac0:	c016      	tjeq	0x2daf0
   2dac2:	5ed0      	tloadr	r0, [r2, #108]	; 0x6c
   2dac4:	b268      	tadds	r2, #104	; 0x68
   2dac6:	2852      	tloadrh	r2, [r2, #2]
   2dac8:	0641      	tmov	r1, r8
   2daca:	9003 98d1 	tjl	0x30c70
   2dace:	a001      	tmovs	r0, #1
   2dad0:	87eb      	tj	0x2daaa
   2dad2:	0d14      	tloadr	r5, [pc, #80]	; (0x2db24) ; LITERAL=0x00846ca8
   2dad4:	a02f      	tmovs	r0, #47	; 0x2f
   2dad6:	0682      	tmov	sl, r0
   2dad8:	1c28      	tloadrb	r0, [r5, r0]
   2dada:	a100      	tmovs	r1, #0
   2dadc:	97ff 9bf8 	tjl	0x2d2d0
   2dae0:	a800      	tcmp	r0, #0
   2dae2:	c1cb      	tjne	0x2da7c
   2dae4:	0653      	tmov	r3, sl
   2dae6:	1ce8      	tloadrb	r0, [r5, r3]
   2dae8:	a100      	tmovs	r1, #0
   2daea:	97ff 9bf1 	tjl	0x2d2d0
   2daee:	87c5      	tj	0x2da7c
   2daf0:	ec14      	tadds	r4, r2, #0
   2daf2:	b464      	tadds	r4, #100	; 0x64
   2daf4:	5e53      	tloadr	r3, [r2, #100]	; 0x64
   2daf6:	fa1b      	tshftrs	r3, r3, #8
   2daf8:	4920      	tloadrb	r0, [r4, #4]
   2dafa:	f600      	tshftls	r0, r0, #24
   2dafc:	0318      	tors	r0, r3
   2dafe:	48cb      	tloadrb	r3, [r1, #3]
   2db00:	490a      	tloadrb	r2, [r1, #4]
   2db02:	f212      	tshftls	r2, r2, #8
   2db04:	031a      	tors	r2, r3
   2db06:	0641      	tmov	r1, r8
   2db08:	9003 98b2 	tjl	0x30c70
   2db0c:	a001      	tmovs	r0, #1
   2db0e:	87cc      	tj	0x2daaa
   2db10:	2ec0      	tloadrh	r0, [r0, #54]	; 0x36
   2db12:	0084      	tshftls	r4, r0
   2db14:	1d0f      	tloadrb	r7, [r1, r4]
   2db16:	0000      	tands	r0, r0
   2db18:	2ffe      	tloadrh	r6, [r7, #62]	; 0x3e
   2db1a:	0000      	tands	r0, r0
   2db1c:	71dc      	tadd	r1, pc, #880	; (tadd r1, 0x2de90)
   2db1e:	0084      	tshftls	r4, r0
   2db20:	2e68      	tloadrh	r0, [r5, #50]	; 0x32
   2db22:	0084      	tshftls	r4, r0
   2db24:	6ca8      	tpop	{r3, r5, r7}
   2db26:	0084      	tshftls	r4, r0
   3a410:	6500      	tpush	{lr}
   3a412:	0b07      	tloadr	r3, [pc, #28]	; (0x3a430) ; LITERAL=0x00843c10
   3a414:	481b      	tloadrb	r3, [r3, #0]
   3a416:	ab01      	tcmp	r3, #1
   3a418:	c108      	tjne	0x3a42c
   3a41a:	0b06      	tloadr	r3, [pc, #24]	; (0x3a434) ; LITERAL=0x0080058b
   3a41c:	481a      	tloadrb	r2, [r3, #0]
   3a41e:	a120      	tmovs	r1, #32
   3a420:	038a      	tbclrs	r2, r1
   3a422:	401a      	tstorerb	r2, [r3, #0]
   3a424:	a0fa      	tmovs	r0, #250	; 0xfa
   3a426:	f080      	tshftls	r0, r0, #2
   3a428:	9000 9d00 	tjl	0x3ae2c
   3a42c:	6d00      	tpop	{pc}
   3a42e:	46c0      	tstorerb	r0, [r0, #27]
   3a430:	3c10      	tloadr	r4, [sp, #64]	; 0x40
   3a432:	0084      	tshftls	r4, r0
   3a434:	058b      	tcmp	fp, r1
   3a436:	0080      	tshftls	r0, r0
   3a438:	6500      	tpush	{lr}
   3a43a:	97ff 9f77 	tjl	0x3a32c
   3a43e:	97ff 9fe7 	tjl	0x3a410
   3a442:	6d00      	tpop	{pc}
   3a444:	65f0      	tpush	{r4, r5, r6, r7, lr}
   3a446:	0c15      	tloadr	r4, [pc, #84]	; (0x3a49c) ; LITERAL=0x0080059b
   3a448:	4823      	tloadrb	r3, [r4, #0]
   3a44a:	a710      	tmovs	r7, #16
   3a44c:	a610      	tmovs	r6, #16
   3a44e:	0333      	tors	r3, r6
   3a450:	f61b      	tshftls	r3, r3, #24
   3a452:	fe1b      	tshftrs	r3, r3, #24
   3a454:	4023      	tstorerb	r3, [r4, #0]
   3a456:	a5fa      	tmovs	r5, #250	; 0xfa
   3a458:	f0ed      	tshftls	r5, r5, #3
   3a45a:	ec28      	tadds	r0, r5, #0
   3a45c:	9000 9ce6 	tjl	0x3ae2c
   3a460:	4823      	tloadrb	r3, [r4, #0]
   3a462:	03bb      	tbclrs	r3, r7
   3a464:	4023      	tstorerb	r3, [r4, #0]
   3a466:	ec28      	tadds	r0, r5, #0
   3a468:	9000 9ce0 	tjl	0x3ae2c
   3a46c:	4823      	tloadrb	r3, [r4, #0]
   3a46e:	0333      	tors	r3, r6
   3a470:	f61b      	tshftls	r3, r3, #24
   3a472:	fe1b      	tshftrs	r3, r3, #24
   3a474:	4023      	tstorerb	r3, [r4, #0]
   3a476:	080a      	tloadr	r0, [pc, #40]	; (0x3a4a0) ; LITERAL=0x00004e20
   3a478:	9000 9cd8 	tjl	0x3ae2c
   3a47c:	4823      	tloadrb	r3, [r4, #0]
   3a47e:	03bb      	tbclrs	r3, r7
   3a480:	4023      	tstorerb	r3, [r4, #0]
   3a482:	ec28      	tadds	r0, r5, #0
   3a484:	9000 9cd2 	tjl	0x3ae2c
   3a488:	4823      	tloadrb	r3, [r4, #0]
   3a48a:	031e      	tors	r6, r3
   3a48c:	f636      	tshftls	r6, r6, #24
   3a48e:	fe36      	tshftrs	r6, r6, #24
   3a490:	4026      	tstorerb	r6, [r4, #0]
   3a492:	ec28      	tadds	r0, r5, #0
   3a494:	9000 9cca 	tjl	0x3ae2c
   3a498:	6df0      	tpop	{r4, r5, r6, r7, pc}
   3a49a:	46c0      	tstorerb	r0, [r0, #27]
   3a49c:	059b      	tcmp	fp, r3
   3a49e:	0080      	tshftls	r0, r0
   3a4a0:	4e20      	tloadrb	r0, [r4, #24]
   3a4a2:	0000      	tands	r0, r0
   3afb8:	a0c0      	tmovs	r0, #192	; 0xc0
   3afba:	f040      	tshftls	r0, r0, #1
   3afbc:	97ff 9922 	tjl	0x3a204
   3afc0:	0c11      	tloadr	r4, [pc, #68]	; (0x3b008) ; LITERAL=0x00011000
   3afc2:	4e22      	tloadrb	r2, [r4, #24]
   3afc4:	4e63      	tloadrb	r3, [r4, #25]
   3afc6:	f21b      	tshftls	r3, r3, #8
   3afc8:	0313      	tors	r3, r2
   3afca:	4ea2      	tloadrb	r2, [r4, #26]
   3afcc:	f412      	tshftls	r2, r2, #16
   3afce:	0313      	tors	r3, r2
   3afd0:	4ee2      	tloadrb	r2, [r4, #27]
   3afd2:	f612      	tshftls	r2, r2, #24
   3afd4:	0313      	tors	r3, r2
   3afd6:	a0c1      	tmovs	r0, #193	; 0xc1
   3afd8:	f080      	tshftls	r0, r0, #2
   3afda:	9000 9817 	tjl	0x3b00c
   3afde:	4c23      	tloadrb	r3, [r4, #16]
   3afe0:	4c65      	tloadrb	r5, [r4, #17]
   3afe2:	f22d      	tshftls	r5, r5, #8
   3afe4:	031d      	tors	r5, r3
   3afe6:	4ca3      	tloadrb	r3, [r4, #18]
   3afe8:	f41b      	tshftls	r3, r3, #16
   3afea:	031d      	tors	r5, r3
   3afec:	4ce3      	tloadrb	r3, [r4, #19]
   3afee:	f61b      	tshftls	r3, r3, #24
   3aff0:	031d      	tors	r5, r3
   3aff2:	066c      	tmov	r4, sp
   3aff4:	b403      	tadds	r4, #3
   3aff6:	a000      	tmovs	r0, #0
   3aff8:	a100      	tmovs	r1, #0
   3affa:	ec22      	tadds	r2, r4, #0
   3affc:	a301      	tmovs	r3, #1
   3affe:	9000 9806 	tjl	0x3b00e
   3b002:	87c3      	tj	0x3af8c
   3b0d6:	a0c0      	tmovs	r0, #192	; 0xc0
   3b0d8:	f040      	tshftls	r0, r0, #1
   3b0da:	97ff 9893 	tjl	0x3a204
   3b0de:	0d11      	tloadr	r5, [pc, #68]	; (0x3b124) ; LITERAL=0x00011000
   3b0e0:	4c2b      	tloadrb	r3, [r5, #16]
   3b0e2:	4c6e      	tloadrb	r6, [r5, #17]
   3b0e4:	f236      	tshftls	r6, r6, #8
   3b0e6:	031e      	tors	r6, r3
   3b0e8:	4cab      	tloadrb	r3, [r5, #18]
   3b0ea:	f41b      	tshftls	r3, r3, #16
   3b0ec:	031e      	tors	r6, r3
   3b0ee:	4ceb      	tloadrb	r3, [r5, #19]
   3b0f0:	f61b      	tshftls	r3, r3, #24
   3b0f2:	031e      	tors	r6, r3
   3b0f4:	a000      	tmovs	r0, #0
   3b0f6:	a100      	tmovs	r1, #0
   3b0f8:	ec22      	tadds	r2, r4, #0
   3b0fa:	a301      	tmovs	r3, #1
   3b0fc:	9000 9815 	tjl	0x3b12a
   3b100:	4d2a      	tloadrb	r2, [r5, #20]
   3b102:	4d6b      	tloadrb	r3, [r5, #21]
   3b104:	f21b      	tshftls	r3, r3, #8
   3b106:	0313      	tors	r3, r2
   3b108:	4daa      	tloadrb	r2, [r5, #22]
   3b10a:	f412      	tshftls	r2, r2, #16
   3b10c:	0313      	tors	r3, r2
   3b10e:	4dea      	tloadrb	r2, [r5, #23]
   3b110:	f612      	tshftls	r2, r2, #24
   3b112:	0313      	tors	r3, r2
   3b114:	a0c1      	tmovs	r0, #193	; 0xc1
   3b116:	f080      	tshftls	r0, r0, #2
   3b118:	9000 9806 	tjl	0x3b128
   3b11c:	87cc      	tj	0x3b0b8
   3b11e:	46c0      	tstorerb	r0, [r0, #27]
   3b540:	f600      	tshftls	r0, r0, #24
   3b542:	fe00      	tshftrs	r0, r0, #24
   3b544:	a819      	tcmp	r0, #25
   3b546:	c037      	tjeq	0x3b5b8
   3b548:	a818      	tcmp	r0, #24
   3b54a:	c041      	tjeq	0x3b5d0
   3b54c:	a81a      	tcmp	r0, #26
   3b54e:	c045      	tjeq	0x3b5dc
   3b550:	a81b      	tcmp	r0, #27
   3b552:	c037      	tjeq	0x3b5c4
   3b554:	a81c      	tcmp	r0, #28
   3b556:	c047      	tjeq	0x3b5e8
   3b558:	a81d      	tcmp	r0, #29
   3b55a:	c04b      	tjeq	0x3b5f4
   3b55c:	a81e      	tcmp	r0, #30
   3b55e:	c04f      	tjeq	0x3b600
   3b560:	a81f      	tcmp	r0, #31
   3b562:	c053      	tjeq	0x3b60c
   3b564:	a820      	tcmp	r0, #32
   3b566:	c05d      	tjeq	0x3b624
   3b568:	a821      	tcmp	r0, #33	; 0x21
   3b56a:	c061      	tjeq	0x3b630
   3b56c:	a822      	tcmp	r0, #34	; 0x22
   3b56e:	c065      	tjeq	0x3b63c
   3b570:	a823      	tcmp	r0, #35	; 0x23
   3b572:	c069      	tjeq	0x3b648
   3b574:	a824      	tcmp	r0, #36	; 0x24
   3b576:	c100      	tjne	0x3b57a
   3b578:	806c      	tj	0x3b654
   3b57a:	a825      	tcmp	r0, #37	; 0x25
   3b57c:	c04c      	tjeq	0x3b618
   3b57e:	a826      	tcmp	r0, #38	; 0x26
   3b580:	c100      	tjne	0x3b584
   3b582:	806d      	tj	0x3b660
   3b584:	a827      	tcmp	r0, #39	; 0x27
   3b586:	c100      	tjne	0x3b58a
   3b588:	8070      	tj	0x3b66c
   3b58a:	a828      	tcmp	r0, #40	; 0x28
   3b58c:	c100      	tjne	0x3b590
   3b58e:	8073      	tj	0x3b678
   3b590:	a829      	tcmp	r0, #41	; 0x29
   3b592:	c100      	tjne	0x3b596
   3b594:	8075      	tj	0x3b682
   3b596:	a82a      	tcmp	r0, #42	; 0x2a
   3b598:	c100      	tjne	0x3b59c
   3b59a:	8078      	tj	0x3b68e
   3b59c:	a82b      	tcmp	r0, #43	; 0x2b
   3b59e:	c100      	tjne	0x3b5a2
   3b5a0:	807b      	tj	0x3b69a
   3b5a2:	a82c      	tcmp	r0, #44	; 0x2c
   3b5a4:	c100      	tjne	0x3b5a8
   3b5a6:	807e      	tj	0x3b6a6
   3b5a8:	a82d      	tcmp	r0, #45	; 0x2d
   3b5aa:	c105      	tjne	0x3b5b8
   3b5ac:	0b41      	tloadr	r3, [pc, #260]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b5ae:	a215      	tmovs	r2, #21
   3b5b0:	439a      	tstorerb	r2, [r3, #14]
   3b5b2:	a228      	tmovs	r2, #40	; 0x28
   3b5b4:	43da      	tstorerb	r2, [r3, #15]
   3b5b6:	8004      	tj	0x3b5c2
   3b5b8:	0b3e      	tloadr	r3, [pc, #248]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b5ba:	a200      	tmovs	r2, #0
   3b5bc:	439a      	tstorerb	r2, [r3, #14]
   3b5be:	a228      	tmovs	r2, #40	; 0x28
   3b5c0:	43da      	tstorerb	r2, [r3, #15]
   3b5c2:	0770      	tjex	lr
   3b5c4:	0b3b      	tloadr	r3, [pc, #236]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b5c6:	a203      	tmovs	r2, #3
   3b5c8:	439a      	tstorerb	r2, [r3, #14]
   3b5ca:	a228      	tmovs	r2, #40	; 0x28
   3b5cc:	43da      	tstorerb	r2, [r3, #15]
   3b5ce:	87f8      	tj	0x3b5c2
   3b5d0:	0b38      	tloadr	r3, [pc, #224]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b5d2:	a201      	tmovs	r2, #1
   3b5d4:	439a      	tstorerb	r2, [r3, #14]
   3b5d6:	a228      	tmovs	r2, #40	; 0x28
   3b5d8:	43da      	tstorerb	r2, [r3, #15]
   3b5da:	87f2      	tj	0x3b5c2
   3b5dc:	0b35      	tloadr	r3, [pc, #212]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b5de:	a202      	tmovs	r2, #2
   3b5e0:	439a      	tstorerb	r2, [r3, #14]
   3b5e2:	a228      	tmovs	r2, #40	; 0x28
   3b5e4:	43da      	tstorerb	r2, [r3, #15]
   3b5e6:	87ec      	tj	0x3b5c2
   3b5e8:	0b32      	tloadr	r3, [pc, #200]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b5ea:	a204      	tmovs	r2, #4
   3b5ec:	439a      	tstorerb	r2, [r3, #14]
   3b5ee:	a279      	tmovs	r2, #121	; 0x79
   3b5f0:	43da      	tstorerb	r2, [r3, #15]
   3b5f2:	87e6      	tj	0x3b5c2
   3b5f4:	0b2f      	tloadr	r3, [pc, #188]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b5f6:	a205      	tmovs	r2, #5
   3b5f8:	439a      	tstorerb	r2, [r3, #14]
   3b5fa:	a228      	tmovs	r2, #40	; 0x28
   3b5fc:	43da      	tstorerb	r2, [r3, #15]
   3b5fe:	87e0      	tj	0x3b5c2
   3b600:	0b2c      	tloadr	r3, [pc, #176]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b602:	a206      	tmovs	r2, #6
   3b604:	439a      	tstorerb	r2, [r3, #14]
   3b606:	a228      	tmovs	r2, #40	; 0x28
   3b608:	43da      	tstorerb	r2, [r3, #15]
   3b60a:	87da      	tj	0x3b5c2
   3b60c:	0b29      	tloadr	r3, [pc, #164]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b60e:	a207      	tmovs	r2, #7
   3b610:	439a      	tstorerb	r2, [r3, #14]
   3b612:	a287      	tmovs	r2, #135	; 0x87
   3b614:	43da      	tstorerb	r2, [r3, #15]
   3b616:	87d4      	tj	0x3b5c2
   3b618:	0b26      	tloadr	r3, [pc, #152]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b61a:	a20d      	tmovs	r2, #13
   3b61c:	439a      	tstorerb	r2, [r3, #14]
   3b61e:	a228      	tmovs	r2, #40	; 0x28
   3b620:	43da      	tstorerb	r2, [r3, #15]
   3b622:	87ce      	tj	0x3b5c2
   3b624:	0b23      	tloadr	r3, [pc, #140]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b626:	a208      	tmovs	r2, #8
   3b628:	439a      	tstorerb	r2, [r3, #14]
   3b62a:	a228      	tmovs	r2, #40	; 0x28
   3b62c:	43da      	tstorerb	r2, [r3, #15]
   3b62e:	87c8      	tj	0x3b5c2
   3b630:	0b20      	tloadr	r3, [pc, #128]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b632:	a209      	tmovs	r2, #9
   3b634:	439a      	tstorerb	r2, [r3, #14]
   3b636:	a228      	tmovs	r2, #40	; 0x28
   3b638:	43da      	tstorerb	r2, [r3, #15]
   3b63a:	87c2      	tj	0x3b5c2
   3b63c:	0b1d      	tloadr	r3, [pc, #116]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b63e:	a20a      	tmovs	r2, #10
   3b640:	439a      	tstorerb	r2, [r3, #14]
   3b642:	a228      	tmovs	r2, #40	; 0x28
   3b644:	43da      	tstorerb	r2, [r3, #15]
   3b646:	87bc      	tj	0x3b5c2
   3b648:	0b1a      	tloadr	r3, [pc, #104]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b64a:	a20b      	tmovs	r2, #11
   3b64c:	439a      	tstorerb	r2, [r3, #14]
   3b64e:	a228      	tmovs	r2, #40	; 0x28
   3b650:	43da      	tstorerb	r2, [r3, #15]
   3b652:	87b6      	tj	0x3b5c2
   3b654:	0b17      	tloadr	r3, [pc, #92]	; (0x3b6b4) ; LITERAL=0x00843c00
   3b656:	a20c      	tmovs	r2, #12
   3b658:	439a      	tstorerb	r2, [r3, #14]
   3b65a:	a228      	tmovs	r2, #40	; 0x28
   3b780:	6530      	tpush	{r4, r5, lr}
   3b782:	0c1a      	tloadr	r4, [pc, #104]	; (0x3b7ec) ; LITERAL=0x00843c00
   3b784:	4ba3      	tloadrb	r3, [r4, #14]
   3b786:	ab11      	tcmp	r3, #17
   3b788:	c029      	tjeq	0x3b7de
   3b78a:	4ba3      	tloadrb	r3, [r4, #14]
   3b78c:	ab0f      	tcmp	r3, #15
   3b78e:	c026      	tjeq	0x3b7de
   3b790:	a041      	tmovs	r0, #65	; 0x41
   3b792:	97ff 9d29 	tjl	0x3b1e8
   3b796:	a000      	tmovs	r0, #0
   3b798:	97ff 9dbe 	tjl	0x3b318
   3b79c:	a040      	tmovs	r0, #64	; 0x40
   3b79e:	97ff 9d23 	tjl	0x3b1e8
   3b7a2:	97ff 9e9f 	tjl	0x3b4e4
   3b7a6:	97ff 9b8d 	tjl	0x3aec4
   3b7aa:	ec05      	tadds	r5, r0, #0
   3b7ac:	97ff 9c30 	tjl	0x3b010
   3b7b0:	f440      	tshftls	r0, r0, #17
   3b7b2:	fe00      	tshftrs	r0, r0, #24
   3b7b4:	f06d      	tshftls	r5, r5, #1
   3b7b6:	0305      	tors	r5, r0
   3b7b8:	ffeb      	tshftrs	r3, r5, #31
   3b7ba:	e95d      	tadds	r5, r3, r5
   3b7bc:	f5ed      	tshftls	r5, r5, #23
   3b7be:	fe2d      	tshftrs	r5, r5, #24
   3b7c0:	42e5      	tstorerb	r5, [r4, #11]
   3b7c2:	4ba3      	tloadrb	r3, [r4, #14]
   3b7c4:	ab11      	tcmp	r3, #17
   3b7c6:	c003      	tjeq	0x3b7d0
   3b7c8:	4ba3      	tloadrb	r3, [r4, #14]
   3b7ca:	ab0f      	tcmp	r3, #15
   3b7cc:	c000      	tjeq	0x3b7d0
   3b7ce:	6d30      	tpop	{r4, r5, pc}
   3b7d0:	a0a2      	tmovs	r0, #162	; 0xa2
   3b7d2:	97ff 9d09 	tjl	0x3b1e8
   3b7d6:	a000      	tmovs	r0, #0
   3b7d8:	97ff 9d9e 	tjl	0x3b318
   3b7dc:	87f7      	tj	0x3b7ce
   3b7de:	a0a2      	tmovs	r0, #162	; 0xa2
   3b7e0:	97ff 9d02 	tjl	0x3b1e8
   3b7e4:	a001      	tmovs	r0, #1
   3b7e6:	97ff 9d97 	tjl	0x3b318
   3b7ea:	87d1      	tj	0x3b790
   3b7ec:	3c00      	tloadr	r4, [sp, #0]
   3b7ee:	0084      	tshftls	r4, r0
   3b7f0:	6510      	tpush	{r4, lr}
   3b7f2:	a040      	tmovs	r0, #64	; 0x40
   3b7f4:	97ff 9cf8 	tjl	0x3b1e8
   3b7f8:	97ff 9e74 	tjl	0x3b4e4
   3b7fc:	97ff 9b62 	tjl	0x3aec4
   3b800:	ec04      	tadds	r4, r0, #0
   3b802:	97ff 9c05 	tjl	0x3b010
   3b806:	f440      	tshftls	r0, r0, #17
   3b808:	fe00      	tshftrs	r0, r0, #24
   3b80a:	f064      	tshftls	r4, r4, #1
   3b80c:	0304      	tors	r4, r0
   3b80e:	ffe3      	tshftrs	r3, r4, #31
   3b810:	e91c      	tadds	r4, r3, r4
   3b812:	f5e4      	tshftls	r4, r4, #23
   3b814:	fe24      	tshftrs	r4, r4, #24
   3b816:	0b01      	tloadr	r3, [pc, #4]	; (0x3b81c) ; LITERAL=0x00843c00
   3b818:	42dc      	tstorerb	r4, [r3, #11]
   3b81a:	6d10      	tpop	{r4, pc}
   3b81c:	3c00      	tloadr	r4, [sp, #0]
   3b81e:	0084      	tshftls	r4, r0
   3bf28:	6500      	tpush	{lr}
   3bf2a:	97ff 9c79 	tjl	0x3b820
   3bf2e:	a04d      	tmovs	r0, #77	; 0x4d
   3bf30:	97ff 995a 	tjl	0x3b1e8
   3bf34:	a078      	tmovs	r0, #120	; 0x78
   3bf36:	97ff 99ef 	tjl	0x3b318
   3bf3a:	a0ae      	tmovs	r0, #174	; 0xae
   3bf3c:	97ff 9954 	tjl	0x3b1e8
   3bf40:	a0af      	tmovs	r0, #175	; 0xaf
   3bf42:	97ff 99e9 	tjl	0x3b318
   3bf46:	a0bd      	tmovs	r0, #189	; 0xbd
   3bf48:	97ff 994e 	tjl	0x3b1e8
   3bf4c:	a080      	tmovs	r0, #128	; 0x80
   3bf4e:	97ff 99e3 	tjl	0x3b318
   3bf52:	a0b0      	tmovs	r0, #176	; 0xb0
   3bf54:	97ff 9948 	tjl	0x3b1e8
   3bf58:	a013      	tmovs	r0, #19
   3bf5a:	97ff 99dd 	tjl	0x3b318
   3bf5e:	a0ad      	tmovs	r0, #173	; 0xad
   3bf60:	97ff 9942 	tjl	0x3b1e8
   3bf64:	a017      	tmovs	r0, #23
   3bf66:	97ff 99d7 	tjl	0x3b318
   3bf6a:	a0b6      	tmovs	r0, #182	; 0xb6
   3bf6c:	97ff 993c 	tjl	0x3b1e8
   3bf70:	a00f      	tmovs	r0, #15
   3bf72:	97ff 99d1 	tjl	0x3b318
   3bf76:	a0ba      	tmovs	r0, #186	; 0xba
   3bf78:	97ff 9936 	tjl	0x3b1e8
   3bf7c:	a02a      	tmovs	r0, #42	; 0x2a
   3bf7e:	97ff 99cb 	tjl	0x3b318
   3bf82:	6d00      	tpop	{pc}
   3bf84:	6500      	tpush	{lr}
   3bf86:	97ff 9c4b 	tjl	0x3b820
   3bf8a:	a04d      	tmovs	r0, #77	; 0x4d
   3bf8c:	97ff 992c 	tjl	0x3b1e8
   3bf90:	a078      	tmovs	r0, #120	; 0x78
   3bf92:	97ff 99c1 	tjl	0x3b318
   3bf96:	a0ae      	tmovs	r0, #174	; 0xae
   3bfe0:	6500      	tpush	{lr}
   3bfe2:	0b09      	tloadr	r3, [pc, #36]	; (0x3c008) ; LITERAL=0x00843c00
   3bfe4:	4b9a      	tloadrb	r2, [r3, #14]
   3bfe6:	aa0f      	tcmp	r2, #15
   3bfe8:	c006      	tjeq	0x3bff8
   3bfea:	4b9b      	tloadrb	r3, [r3, #14]
   3bfec:	ab11      	tcmp	r3, #17
   3bfee:	c003      	tjeq	0x3bff8
   3bff0:	a010      	tmovs	r0, #16
   3bff2:	97ff 98f9 	tjl	0x3b1e8
   3bff6:	6d00      	tpop	{pc}
   3bff8:	a0a2      	tmovs	r0, #162	; 0xa2
   3bffa:	97ff 98f5 	tjl	0x3b1e8
   3bffe:	a001      	tmovs	r0, #1
   3c000:	97ff 998a 	tjl	0x3b318
   3c004:	87f4      	tj	0x3bff0
   3c006:	46c0      	tstorerb	r0, [r0, #27]
   3c008:	3c00      	tloadr	r4, [sp, #0]
   3c00a:	0084      	tshftls	r4, r0
   3c00c:	6500      	tpush	{lr}
   3c00e:	0b09      	tloadr	r3, [pc, #36]	; (0x3c034) ; LITERAL=0x00843c00
   3c010:	4b9a      	tloadrb	r2, [r3, #14]
   3c012:	aa0f      	tcmp	r2, #15
   3c014:	c006      	tjeq	0x3c024
   3c016:	4b9b      	tloadrb	r3, [r3, #14]
   3c018:	ab11      	tcmp	r3, #17
   3c01a:	c003      	tjeq	0x3c024
   3c01c:	a010      	tmovs	r0, #16
   3c01e:	97ff 98e3 	tjl	0x3b1e8
   3c022:	6d00      	tpop	{pc}
   3c024:	a0a2      	tmovs	r0, #162	; 0xa2
   3c026:	97ff 98df 	tjl	0x3b1e8
   3c02a:	a002      	tmovs	r0, #2
   3c02c:	97ff 9974 	tjl	0x3b318
   3c030:	87f4      	tj	0x3c01c
   3c032:	46c0      	tstorerb	r0, [r0, #27]
   3c034:	3c00      	tloadr	r4, [sp, #0]
   3c036:	0084      	tshftls	r4, r0
   3c038:	6500      	tpush	{lr}
   3c03a:	a0ff      	tmovs	r0, #255	; 0xff
   3c310:	6510      	tpush	{r4, lr}
   3c312:	0c36      	tloadr	r4, [pc, #216]	; (0x3c3ec) ; LITERAL=0x00843c00
   3c314:	4ba3      	tloadrb	r3, [r4, #14]
   3c316:	ab06      	tcmp	r3, #6
   3c318:	c045      	tjeq	0x3c3a6
   3c31a:	4ba3      	tloadrb	r3, [r4, #14]
   3c31c:	ab10      	tcmp	r3, #16
   3c31e:	c042      	tjeq	0x3c3a6
   3c320:	4ba3      	tloadrb	r3, [r4, #14]
   3c322:	ab09      	tcmp	r3, #9
   3c324:	c044      	tjeq	0x3c3b0
   3c326:	4ba3      	tloadrb	r3, [r4, #14]
   3c328:	ab08      	tcmp	r3, #8
   3c32a:	c046      	tjeq	0x3c3ba
   3c32c:	4ba3      	tloadrb	r3, [r4, #14]
   3c32e:	ab00      	tcmp	r3, #0
   3c330:	c00c      	tjeq	0x3c34c
   3c332:	4ba3      	tloadrb	r3, [r4, #14]
   3c334:	ab11      	tcmp	r3, #17
   3c336:	c009      	tjeq	0x3c34c
   3c338:	4ba3      	tloadrb	r3, [r4, #14]
   3c33a:	ab07      	tcmp	r3, #7
   3c33c:	c006      	tjeq	0x3c34c
   3c33e:	4aa2      	tloadrb	r2, [r4, #10]
   3c340:	a37f      	tmovs	r3, #127	; 0x7f
   3c342:	039a      	tbclrs	r2, r3
   3c344:	c048      	tjeq	0x3c3d8
   3c346:	4aa2      	tloadrb	r2, [r4, #10]
   3c348:	0013      	tands	r3, r2
   3c34a:	42a3      	tstorerb	r3, [r4, #10]
   3c34c:	4ba3      	tloadrb	r3, [r4, #14]
   3c34e:	ab06      	tcmp	r3, #6
   3c350:	c036      	tjeq	0x3c3c0
   3c352:	4ba3      	tloadrb	r3, [r4, #14]
   3c354:	ab10      	tcmp	r3, #16
   3c356:	c033      	tjeq	0x3c3c0
   3c358:	4ba3      	tloadrb	r3, [r4, #14]
   3c35a:	ab11      	tcmp	r3, #17
   3c35c:	c035      	tjeq	0x3c3ca
   3c35e:	a012      	tmovs	r0, #18
   3c360:	97fe 9f42 	tjl	0x3b1e8
   3c364:	a000      	tmovs	r0, #0
   3c366:	97fe 9fd7 	tjl	0x3b318
   3c36a:	a202      	tmovs	r2, #2
   3c36c:	0b20      	tloadr	r3, [pc, #128]	; (0x3c3f0) ; LITERAL=0x00843c12
   3c36e:	401a      	tstorerb	r2, [r3, #0]
   3c370:	0820      	tloadr	r0, [pc, #128]	; (0x3c3f4) ; LITERAL=0x00002710
   3c372:	97fe 9d5b 	tjl	0x3ae2c
   3c376:	0b20      	tloadr	r3, [pc, #128]	; (0x3c3f8) ; LITERAL=0x00843c11
   3c378:	481b      	tloadrb	r3, [r3, #0]
   3c37a:	abaa      	tcmp	r3, #170	; 0xaa
   3c37c:	c009      	tjeq	0x3c392
   3c37e:	a002      	tmovs	r0, #2
   3c380:	97fd 9f5a 	tjl	0x3a238
   3c384:	a800      	tcmp	r0, #0
   3c386:	c109      	tjne	0x3c39c
   3c388:	4aa2      	tloadrb	r2, [r4, #10]
   3c38a:	a304      	tmovs	r3, #4
   3c38c:	0313      	tors	r3, r2
   3c38e:	42a3      	tstorerb	r3, [r4, #10]
   3c390:	6d10      	tpop	{r4, pc}
   3c392:	a002      	tmovs	r0, #2
   3c394:	97fd 9f50 	tjl	0x3a238
   3c398:	a800      	tcmp	r0, #0
   3c39a:	c1f5      	tjne	0x3c388
   3c39c:	4aa3      	tloadrb	r3, [r4, #10]
   3c39e:	a204      	tmovs	r2, #4
   3c3a0:	0393      	tbclrs	r3, r2
   3c3a2:	42a3      	tstorerb	r3, [r4, #10]
   3c3a4:	87f4      	tj	0x3c390
   3c3a6:	97ff 9e47 	tjl	0x3c038
   3c3aa:	4ba3      	tloadrb	r3, [r4, #14]
   3c3ac:	ab09      	tcmp	r3, #9
   3c3ae:	c1ba      	tjne	0x3c326
   3c3b0:	97ff 9f1a 	tjl	0x3c1e8
   3c3b4:	4ba3      	tloadrb	r3, [r4, #14]
   3c3b6:	ab08      	tcmp	r3, #8
   3c3b8:	c1b8      	tjne	0x3c32c
   3c3ba:	97ff 9ecd 	tjl	0x3c158
   3c3be:	87b5      	tj	0x3c32c
   3c3c0:	97ff 9e94 	tjl	0x3c0ec
   3c3c4:	4ba3      	tloadrb	r3, [r4, #14]
   3c3c6:	ab11      	tcmp	r3, #17
   3c3c8:	c1c9      	tjne	0x3c35e
   3c3ca:	a0a2      	tmovs	r0, #162	; 0xa2
   3c3cc:	97fe 9f0c 	tjl	0x3b1e8
   3c3d0:	a000      	tmovs	r0, #0
   3c3d2:	97fe 9fa1 	tjl	0x3b318
   3c3d6:	87c2      	tj	0x3c35e
   3c3d8:	a004      	tmovs	r0, #4
   3c3da:	97fe 9f05 	tjl	0x3b1e8
   3c3de:	a0fa      	tmovs	r0, #250	; 0xfa
   3c3e0:	f080      	tshftls	r0, r0, #2
   3c3e2:	97fe 9d23 	tjl	0x3ae2c
   3c3e6:	97ff 987d 	tjl	0x3b4e4
   3c3ea:	87af      	tj	0x3c34c
   3c3ec:	3c00      	tloadr	r4, [sp, #0]
   3c3ee:	0084      	tshftls	r4, r0
   3c3f0:	3c12      	tloadr	r4, [sp, #72]	; 0x48
   3c3f2:	0084      	tshftls	r4, r0
   3c3f4:	2710      	tstorerh	r0, [r2, #56]	; 0x38
   3c3f6:	0000      	tands	r0, r0
   3c3f8:	3c11      	tloadr	r4, [sp, #68]	; 0x44
   3c3fa:	0084      	tshftls	r4, r0
   3dc3c:	6530      	tpush	{r4, r5, lr}
   3dc3e:	0c47      	tloadr	r4, [pc, #284]	; (0x3dd5c) ; LITERAL=0x00843c12
   3dc40:	4823      	tloadrb	r3, [r4, #0]
   3dc42:	ab01      	tcmp	r3, #1
   3dc44:	c024      	tjeq	0x3dc90
   3dc46:	ab02      	tcmp	r3, #2
   3dc48:	c008      	tjeq	0x3dc5c
   3dc4a:	a007      	tmovs	r0, #7
   3dc4c:	97fd 9acc 	tjl	0x3b1e8
   3dc50:	a0a5      	tmovs	r0, #165	; 0xa5
   3dc52:	97fd 9b61 	tjl	0x3b318
   3dc56:	a300      	tmovs	r3, #0
   3dc58:	4023      	tstorerb	r3, [r4, #0]
   3dc5a:	6d30      	tpop	{r4, r5, pc}
   3dc5c:	0b40      	tloadr	r3, [pc, #256]	; (0x3dd60) ; LITERAL=0x00843c00
   3dc5e:	4b9b      	tloadrb	r3, [r3, #14]
   3dc60:	ab11      	tcmp	r3, #17
   3dc62:	c04a      	tjeq	0x3dcfa
   3dc64:	a000      	tmovs	r0, #0
   3dc66:	97fd 9abf 	tjl	0x3b1e8
   3dc6a:	a027      	tmovs	r0, #39	; 0x27
   3dc6c:	97fd 9b54 	tjl	0x3b318
   3dc70:	a0a9      	tmovs	r0, #169	; 0xa9
   3dc72:	97fd 9b51 	tjl	0x3b318
   3dc76:	a002      	tmovs	r0, #2
   3dc78:	97fd 9ab6 	tjl	0x3b1e8
   3dc7c:	a000      	tmovs	r0, #0
   3dc7e:	97fd 9b4b 	tjl	0x3b318
   3dc82:	97fd 9c2f 	tjl	0x3b4e4
   3dc86:	a0fa      	tmovs	r0, #250	; 0xfa
   3dc88:	f080      	tshftls	r0, r0, #2
   3dc8a:	97fd 98cf 	tjl	0x3ae2c
   3dc8e:	87dc      	tj	0x3dc4a
   3dc90:	97fe 9afe 	tjl	0x3c290
   3dc94:	a801      	tcmp	r0, #1
   3dc96:	c037      	tjeq	0x3dd08
   3dc98:	0d31      	tloadr	r5, [pc, #196]	; (0x3dd60) ; LITERAL=0x00843c00
   3dc9a:	4bab      	tloadrb	r3, [r5, #14]
   3dc9c:	ab11      	tcmp	r3, #17
   3dc9e:	c1f2      	tjne	0x3dc86
   3dca0:	a0e0      	tmovs	r0, #224	; 0xe0
   3dca2:	97fd 9aa1 	tjl	0x3b1e8
   3dca6:	a001      	tmovs	r0, #1
   3dca8:	97fd 9b36 	tjl	0x3b318
   3dcac:	4ba8      	tloadrb	r0, [r5, #14]
   3dcae:	48eb      	tloadrb	r3, [r5, #3]
   3dcb0:	492a      	tloadrb	r2, [r5, #4]
   3dcb2:	f212      	tshftls	r2, r2, #8
   3dcb4:	031a      	tors	r2, r3
   3dcb6:	4969      	tloadrb	r1, [r5, #5]
   3dcb8:	49ab      	tloadrb	r3, [r5, #6]
   3dcba:	f21b      	tshftls	r3, r3, #8
   3dcbc:	030b      	tors	r3, r1
   3dcbe:	0929      	tloadr	r1, [pc, #164]	; (0x3dd64) ; LITERAL=0x00843c14
   3dcc0:	4809      	tloadrb	r1, [r1, #0]
   3dcc2:	97ff 9dff 	tjl	0x3d8c4
   3dcc6:	a004      	tmovs	r0, #4
   3dcc8:	97fd 9a8e 	tjl	0x3b1e8
   3dccc:	a0fa      	tmovs	r0, #250	; 0xfa
   3dcce:	f080      	tshftls	r0, r0, #2
   3dcd0:	97fd 98ac 	tjl	0x3ae2c
   3dcd4:	97fd 9c06 	tjl	0x3b4e4
   3dcd8:	a0fa      	tmovs	r0, #250	; 0xfa
   3dcda:	f080      	tshftls	r0, r0, #2
   3dcdc:	97fd 98a6 	tjl	0x3ae2c
   3dce0:	a002      	tmovs	r0, #2
   3dce2:	97fd 9a81 	tjl	0x3b1e8
   3dce6:	a000      	tmovs	r0, #0
   3dce8:	97fd 9b16 	tjl	0x3b318
   3dcec:	a0fa      	tmovs	r0, #250	; 0xfa
   3dcee:	f080      	tshftls	r0, r0, #2
   3dcf0:	97fd 989c 	tjl	0x3ae2c
   3dcf4:	97fd 9bf6 	tjl	0x3b4e4
   3dcf8:	87c5      	tj	0x3dc86
   3dcfa:	a0e0      	tmovs	r0, #224	; 0xe0
   3dcfc:	97fd 9a74 	tjl	0x3b1e8
   3dd00:	a001      	tmovs	r0, #1
   3dd02:	97fd 9b09 	tjl	0x3b318
   3dd06:	87ad      	tj	0x3dc64
   3dd08:	a04d      	tmovs	r0, #77	; 0x4d
   3dd0a:	97fd 9a6d 	tjl	0x3b1e8
   3dd0e:	a078      	tmovs	r0, #120	; 0x78
   3dd10:	97fd 9b02 	tjl	0x3b318
   3dd14:	a0b6      	tmovs	r0, #182	; 0xb6
   3dd16:	97fd 9a67 	tjl	0x3b1e8
