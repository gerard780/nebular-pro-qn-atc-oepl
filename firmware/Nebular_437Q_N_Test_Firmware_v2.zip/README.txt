Nebular Pro-437Q-N / HS9118 experimental test firmware v2
Built October 8, 2026

EXPERIMENTAL_ATC_Nebular_437Q_N_v2.bin is a real TC32 application binary,
123,204 bytes, patched into the pinned ATC_BLE_OEPL reference. It retains
ATC's BLE/OEPL integration and adds a dedicated 437 display adapter.
It is NOT physically tested on a 437. Boot, radio compatibility, physical
orientation, SPI timing and the complete refresh lifecycle remain unverified.

Changes from v1
  Source-checked stock traces corrected power settling to1ms and reset to
  high2/low2/high20/low2/high2 milliseconds. Normal shutdown now sends
  command00 with27 A9 before0200, waits for BUSY, then waits1ms before07A5.
  v1 is retained separately. DEEP-DIVE.md records addresses and evidence.

Quick test
  1. Keep two matching full 512 KiB backups of YOUR physical tag before writing.
  2. Use a wired SWS programmer to program the application at address 0x00000.
     Preserve the upper flash; do not mass-erase. See installation below.
  3. Add 74.json to your OEPL AP's /tagtypes/ directory, then reload the AP's
     tag-type metadata (restart if needed). Check that this local filename is
     unused first. The firmware reports hardware type 0x74 (decimal116).
  4. At room temperature, send test-pattern.jpg through the AP image-upload
     flow with rotation0, inversion0, dithering0 and the normal/full LUT.
     Use uncompressed RAW1/RAW2; this profile omits compression capabilities.
     The numbered white/black/red/yellow bars and border check color/order.
     test-pattern.png is the lossless reference. AP/radio integration on the
     437 is pending hardware validation; this package does not assume success.

This image waits for a received image; it does not automatically draw the
pattern on boot. The test image is uploaded separately. A stock stored page
is not an ATC RAW image and is not automatically replayed.

Supported revision
  Only the exact 92-byte factory product record recovered from the linked
  steanlab 437Q-N HS9118 capture is recognized. A mismatch selects no-display
  preset0 before refresh. Another 437 hardware revision needs its own capture.
  Recognition data is in manifest.json; the factory record remains at0x7e000.
  Native geometry176x480; AP landscape profile480x176, rotatebuffer1.
  Stock driver43 / kind19, with the 437's own booster and command65 override.
  Both refresh passes use their own factory waveform and border byte37/97.
  All16 waveform records are embedded using lossless bounded decompression.
  Runtime refresh accepts only MCU temperature readings15..30C inclusive.
  The MCU reading is not the stock panel-temperature measurement. If the tag
  reads outside this range the display adapter refuses the image; do not
  treat that refusal as proof of an SPI failure or successful screen update.
  An AP completion/acknowledgment does not establish a successful display
  update: the adapter terminates its wait on both success and panel error.
  Check the physical screen and UART diagnostics when testing.
  LED and NFC pointers are disabled because their 437 pins are unconfirmed.
  The recovered EPD pins are resetPD4, DC PB7, BUSY PA1, CS PD2, clockPD7,
  dataPB6 and active-low powerPB5. ATC software SPI is used; stock uses
  hardware SPI with divider0. These physical connections were not probed.

Wired installation and recovery
  Use your existing SWS setup for this PCB with the tag battery disconnected.
  This package does not connect to a programmer or assume a programmer version,
  serial number or pad layout. Use your established signal/power arrangement.
  Verify chip-register bytes026255 and flash JEDECeb6013 match the capture.
  Read the complete512KiB twice, compare both hashes, and retain a local backup.
  Do not replace your tag's identity/calibration with the public GitHub dump.

  Optionally prepare exact sectors and expected readback without opening hardware:
    python3 prepare_flash.py --before /path/to/YOUR-backup.bin --output plan

  The tool rejects a different factory record or damaged firmware. It produces:
    application-padded.bin: write at0, length0x1f000 (126,976bytes).
    flash-plan.json: only changed4KiB sectors, sector0 last.
    expected-full-flash.bin: full512KiB expected result for readback comparison.
    recovery-application.bin: original bytes covering the overwritten sectors.
  These generated files contain per-tag data; keep them private.
  The unpadded firmware may also be written at0 with your established flasher,
  provided sector erasure stops at0x1f000. Never erase at/above0x20000.
  Verify each written sector and the complete flash before releasing reset.
  The plan preserves every byte at/above0x1f000; factory data at0x78000..0x7ffff
  and the rest of the original upper flash remain untouched by installation.
  During normal operation ATC can update its settings and image storage.

  If the test fails, restore recovery-application.bin at0 only if the upper
  flash still matches the same-tag pre-install backup. If ATC has updated
  settings/images, restore YOUR complete same-tag512KiB backup instead and
  verify its full hash. Never restore another tag's backup. Use wired recovery;
  OTA installation/update has not been validated for this build.

Offline validation
  - All16 captured initialization command/data traces match exactly.
  - 24 paired refresh cases cover RAW1/RAW2 and every captured waveform bank.
    Extreme banks are checked offline but blocked by the ambient runtime gate.
  - All84,480 pixels of an asymmetric source, all92 product-byte mutations,
    all256 signed temperature encodings, bad images, all5 BUSY timeout paths,
    stream-fault power cut, timer wrap, and boot identity preservation pass.
  - Final header/CRC, hook addresses, base patch boundaries, memory limits,
    GPIO pointer retention and the AP profile are checked.
  - Power/reset and normal shutdown match source-checked stock trace oracles,
    including both immediate and delayed power-off BUSY release.
  These are software checks; no 437 hardware success is claimed.
  A reset/initialize/BUSY/image/power-on/refresh/power-off/sleep sequence runs
  once per component. Initialization waits for BUSY before pixel transfer.

Rebuild (Linux, Python3, host C compiler and a TC32 toolchain)
  The source directory includes pinned build inputs and minimal type headers.
    NEBULAR_TC32=/path/to/tc32_linux python3 source/build.py
    python3 source/verify_image.py
    python3 source/test_flash_plan.py
  NEBULAR_TC32 must contain bin/tc32-elf-gcc, objcopy, objdump and
  tc32-elf/bin/ld. Generated files stay inside source; no hardware is opened.
  Optional test-image regeneration needs Pillow:
    python3 source/make_test_assets.py
  SHA256SUMS covers the packaged files; verify with sha256sum -c SHA256SUMS.

Provenance and attribution
  Source capture commit716d369dd4c8b1d1877ce4bf777423de3a84bac9:
  https://github.com/steanlab/solum-newton-esl-archive/tree/716d369dd4c8b1d1877ce4bf777423de3a84bac9/tags/Non-Solum/Hanshow-Nebular-Pro-437Q-N-HS9118/SWire/Dumps
  Stock SHA256d7b1b7220a8c8872866d77e1220a0e72666e4b3a8db31c3c880717fc0ee833ae.
  ATC_BLE_OEPL base by atc1441: https://github.com/atc1441/ATC_BLE_OEPL
  Base SHA25626dc327d40d7db62c3867da8a9ae0a5092728404ca9942eae402720b5d72337c.
  Adapter derived from the workspace's unified154/266 experiment, isolated
  here with dedicated437 geometry, setup, waveforms and runtime restrictions.
  OpenEPaperLink profile structure: https://github.com/OpenEPaperLink/OpenEPaperLink
  OpenEPaperLink license text is included as LICENSE-OEPL.txt. Third-party
  binaries, captured waveform data and other material retain their original
  rights; this package does not assign a new license to third-party material.
