#!/usr/bin/env python3
"""Build the dedicated ambient-only 437 test image; never opens hardware."""
from pathlib import Path
import hashlib,json,struct,subprocess,zlib,os
HERE=Path(__file__).resolve().parent
TC=Path(os.environ.get('NEBULAR_TC32','/tmp/oepl-analysis-tools/tc32_linux'))
INPUTS=HERE/'inputs'; OUT=HERE/'dist'; OUT.mkdir(exist_ok=True)
def sha(b): return hashlib.sha256(b).hexdigest()
def run(*a): subprocess.run([str(x) for x in a],check=True)
def call(source,target):
 delta=target-source-4
 assert delta%2==0 and -(1<<22)<=delta<(1<<22)
 return struct.pack('<HH',0x9000|((delta>>12)&0x7ff),0x9800|((delta>>1)&0x7ff))
def compress(data):
 out=bytearray();literal=bytearray();pos=0
 def flush():
  while literal:
   n=min(128,len(literal));out.append(n-1);out.extend(literal[:n]);del literal[:n]
 while pos<len(data):
  best=distance=0
  for d in range(1,min(128,pos)+1):
   n=0
   while n<130 and pos+n<len(data) and data[pos+n]==data[pos+n-d]: n+=1
   if n>best:best=n;distance=d
  if best>=3:flush();out.extend((128+best-3,distance));pos+=best
  else:
   literal.append(data[pos]);pos+=1
   if len(literal)==128:flush()
 flush();return bytes(out)
def decompress(data):
 out=bytearray();pos=0
 while pos<len(data):
  token=data[pos];pos+=1
  if token<128:
   n=token+1;assert pos+n<=len(data);out.extend(data[pos:pos+n]);pos+=n
  else:
   n=(token&127)+3;distance=data[pos];pos+=1;assert 1<=distance<=min(128,len(out))
   for _ in range(n):out.append(out[-distance])
 return bytes(out)
# Verify every portable input against the manifest captured before implementation.
for name,expected in json.loads((INPUTS/'hashes.json').read_text()).items():
 assert sha((INPUTS/name).read_bytes())==expected,name
product=(INPUTS/'product-record.bin').read_bytes()
assert len(product)==92 and struct.unpack_from('<HHH',product,18)==(176,480,437) and product[47]==43
(HERE/'products.inc').write_text('static const uint8_t product_models[1]={0};\nstatic const uint8_t product_records[1][92]={{'+','.join(map(str,product))+'}};\n')
records=[];blob=bytearray();waves=[];oracles=[]
for band in range(8):
 for phase in range(2):
  name=f'band-{band:02d}-mode-{phase+1}'
  data=(INPUTS/'waves'/(name+'.bin')).read_bytes()
  assert len(data)==552 and data[535:]==bytes.fromhex('0f0006070f033f15372529650400200000')
  packed=compress(data[7:535]);assert decompress(packed)==data[7:535]
  records.append('{ {'+','.join(map(str,data[:7]))+'}, '+str(len(blob))+', '+str(len(packed))+' }')
  waves.append(dict(band=band,mode=phase+1,sha256=sha(data),compressed_bytes=len(packed)))
  blob.extend(packed)
  trace=json.loads((INPUTS/'traces'/(name+'-init.json')).read_text())
  assert len(trace)==15 and trace[-1]['command']=='20' and bytes.fromhex(trace[-1]['data_hex'])==data[:535]
  oracles.append('{'+','.join('{'+str(int(row['command'],16))+','+str(row['bytes'])+',{'+','.join(map(str,bytes.fromhex(row['data_hex'])))+'}}' for row in trace)+'}')
(HERE/'waves.inc').write_text('static const int8_t temperature_upper[8]={2,6,9,15,20,25,30,127};\nstatic const struct wave_record wave_records[16]={\n'+',\n'.join(records)+'\n};\nstatic const uint8_t wave_bytes['+str(len(blob))+']={\n'+',\n'.join(','.join(map(str,blob[o:o+32])) for o in range(0,len(blob),32))+'\n};\n')
(HERE/'test_oracles.inc').write_text('struct expected_register {unsigned command,count;uint8_t data[535];};\nstatic const struct expected_register expected_init[16][15]={\n'+',\n'.join(oracles)+'\n};\n')
lifecycle=json.loads((INPUTS/'lifecycle-traces.json').read_text())
event_ids={'power':1,'reset':2,'command':3,'data':4,'delay_us':5,'wait_ready':6}
lines=[]
for name,events in [('reset',lifecycle['traces']['power']['events']+lifecycle['traces']['reset']['events']),('shutdown',lifecycle['traces']['shutdown']['events'])]:
 lines.append('static const unsigned expected_'+name+'[][2]={'+','.join('{'+str(event_ids[k])+','+str(v)+'}' for k,v in events)+'};')
(HERE/'lifecycle_oracles.inc').write_text('\n'.join(lines)+'\n')
run('cc','-std=c99','-Wall','-Wextra','-Werror','-O2','-I',HERE,HERE/'test_lifecycle.c',HERE/'panel.c','-o',HERE/'test_lifecycle')
run(HERE/'test_lifecycle')
run('cc','-std=c99','-Wall','-Wextra','-Werror','-O2','-I',HERE,HERE/'test_437.c',HERE/'panel.c','-o',HERE/'test_437')
run(HERE/'test_437',INPUTS/'waves')
flags=['-std=c99','-Os','-Wall','-Wextra','-Werror','-ffreestanding','-fno-builtin','-fomit-frame-pointer','-ffunction-sections','-fdata-sections','-I',HERE,'-I',INPUTS/'include']
for name in ('panel','adapter'):run(TC/'bin/tc32-elf-gcc',*flags,'-c',HERE/(name+'.c'),'-o',HERE/(name+'.o'))
run(TC/'tc32-elf/bin/ld','-T',HERE/'unified.link','-Map',HERE/'firmware.map','-o',HERE/'firmware.elf',HERE/'panel.o',HERE/'adapter.o')
objdump=TC/'bin/tc32-elf-objdump'
wanted=['nebular_boot','adapter_image','adapter_init','adapter_refresh','adapter_ready','adapter_sleep'];symbols={}
for line in subprocess.check_output([str(objdump),'-t',str(HERE/'firmware.elf')],text=True).splitlines():
 f=line.split()
 if f and f[-1] in wanted:symbols[f[-1]]=int(f[0],16)
assert set(symbols)==set(wanted)
(HERE/'symbols.json').write_text(json.dumps(symbols,indent=2)+'\n')
(HERE/'firmware.asm').write_text(subprocess.check_output([str(objdump),'-d',str(HERE/'firmware.elf')],text=True))
for section in ('core','payload'):run(TC/'bin/tc32-elf-objcopy','-O','binary','-j','.'+section,HERE/'firmware.elf',HERE/(section+'.bin'))
core=(HERE/'core.bin').read_bytes();payload=(HERE/'payload.bin').read_bytes();assert len(core)<=0x630
base=(INPUTS/'ATC_BLE_OEPL-reference.bin').read_bytes()
assert sha(base)=='26dc327d40d7db62c3867da8a9ae0a5092728404ca9942eae402720b5d72337c'
assert base[0xc896:0xc89a]==call(0xc896,0xd84c) and len(base)<0x1c900
image=bytearray(base+b'\xff'*(0x1c900-len(base))+payload)
image[0x6260:0x6260+len(core)]=core
for addr,hook in json.loads((INPUTS/'hooks.json').read_text()).items():
 off=int(addr,16);assert base[off:off+8].hex()==hook['original']
 image[off:off+8]=struct.pack('<HHI',0x0b00,0x0718,symbols[hook['symbol']]|1)
image[0xc896:0xc89a]=call(0xc896,symbols['nebular_boot'])
# Preset17 has the source-recovered 437 EPD GPIOs; LED/NFC have not been mapped.
off=0x1b188+17*42
assert struct.unpack_from('<H',base,off+2)[0]==5
assert base[off+21:off+25]==bytes.fromhex('ac398400')
struct.pack_into('<H',image,off,0x74);struct.pack_into('<HH',image,off+7,480,176)
image[off+25:off+33]=bytes(8) # no LED or NFC initialization
zero=base[0x1b188:0x1b188+42]
assert struct.unpack_from('<H',zero,2)[0]==0 and zero[21:37]==bytes(16)
image[len(base)-4:len(base)]=b'\xff'*4
image+=b'\xff'*((-len(image))%16);struct.pack_into('<I',image,24,len(image)+4)
image+=struct.pack('<I',zlib.crc32(image)^0xffffffff)
assert len(image)<0x20000 and image[8:12]==b'KNLT'
name='EXPERIMENTAL_ATC_Nebular_437Q_N_v2.bin';(OUT/name).write_bytes(image)
meta=dict(firmware=name,sha256=sha(image),bytes=len(image),core_bytes=len(core),payload_bytes=len(payload),compressed_waveform_bytes=len(blob),reserved_state_bytes=300,native_geometry=[176,480],profile_geometry=[480,176],oepl_type='74',preset=17,driver_id=43,application_start=0,application_limit=0x20000,preserve_start=0x20000,preserve_end=0x80000,detection='Exact 92-byte captured product at 0x7e000; unknown product selects no-display preset0',accepted_product_record=product.hex(),runtime_temperature_c=[15,30],waveforms=waves,lifecycle_revision=2,lifecycle_changes=['Power settling 1ms','Reset H2/L2/H20/L2/H2 milliseconds','Pre-power-off command 00 27 A9','1ms after power-off BUSY release before sleep'],status='Offline checks passed; NOT physically tested',base_sha256=sha(base),stock_sha256='d7b1b7220a8c8872866d77e1220a0e72666e4b3a8db31c3c880717fc0ee833ae',source_commit='716d369dd4c8b1d1877ce4bf777423de3a84bac9',limitations=['Wired application-only installation; no OTA validation','RAW1/RAW2 only; no compressed images','MCU temperature instead of stock EPD temperature; ambient-only gate','Reset and normal shutdown match source-checked stock traces; lifecycle/GPIO/timing untested on437 hardware','ATC software SPI instead of stock hardware SPI divider0','Local OEPL type74 is not an upstream allocation','LED/NFC disabled','Completion status terminates on success or error; inspect screen/UART to confirm update'])
(OUT/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({k:v for k,v in meta.items() if k!='waveforms'},indent=2))
