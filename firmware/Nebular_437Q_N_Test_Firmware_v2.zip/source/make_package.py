#!/usr/bin/env python3
"""Create the portable v2 package after running the build and checks."""
import hashlib,zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
files={f.name:f.read_bytes() for f in (P/'dist').iterdir() if f.is_file() and f.name!='SHA256SUMS'}
files['prepare_flash.py']=(P/'prepare_flash.py').read_bytes()
for f in P.iterdir():
 if f.is_file() and f.suffix in ('.py','.c','.h','.link'):files['source/'+f.name]=f.read_bytes()
for f in (P/'inputs').rglob('*'):
 if f.is_file():files['source/'+str(f.relative_to(P))]=f.read_bytes()
files['source/dist/74.json']=(P/'dist/74.json').read_bytes()
research=P.parent/'deep-dive-20261008'
for name in ['lifecycle-traces.json','wave-selection-traces.json','temperature-verification.json','source-excerpts.asm']:
 files['evidence/'+name]=(research/name).read_bytes()
sums=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items()))
(P/'dist/SHA256SUMS').write_text(sums);files['SHA256SUMS']=sums.encode()
output=P.parent/'Nebular_437Q_N_Test_Firmware_v2.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):
  info=zipfile.ZipInfo(name,(2026,10,8,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,data)
print(output,len(files),'files',output.stat().st_size,'bytes',hashlib.sha256(output.read_bytes()).hexdigest())
