#include <assert.h>
#include <stdio.h>
#include "panel.h"
#include "lifecycle_oracles.inc"
struct event {unsigned kind,value;};
static struct event events[80];
static unsigned count,now,busy=1;
static void record(unsigned kind,unsigned value){assert(count<80);events[count].kind=kind;events[count++].value=value;}
static void power(void *p,uint8_t x){(void)p;record(1,x);}
static void reset(void *p,uint8_t x){(void)p;record(2,x);}
static void command(void *p,uint8_t x){(void)p;record(3,x);}
static void data(void *p,uint8_t x){(void)p;record(4,x);}
static void delay(void *p,unsigned x){(void)p;record(5,x*1000);now+=x;}
static uint8_t ready(void *p){(void)p;if(busy)record(6,0);return busy;}
static uint32_t millis(void *p){(void)p;return now;}
static uint8_t pixel(void *p,uint32_t x){(void)p;(void)x;return 5;}
static uint8_t wave(void *p,unsigned x,unsigned y){(void)p;(void)x;(void)y;return 0;}
static const struct nebular_io io={power,reset,command,data,delay,ready,millis,pixel,wave};
static void compare(unsigned offset,const unsigned (*expected)[2],unsigned n){unsigned i;assert(count>=offset+n);for(i=0;i<n;++i){assert(events[offset+i].kind==expected[i][0]);assert(events[offset+i].value==expected[i][1]);}}
int main(void){
 struct nebular_panel p={0};unsigned k;
 assert(nebular_start(&p,&io,0,0));
 assert(count==sizeof(expected_reset)/sizeof(expected_reset[0]));
 compare(0,expected_reset,sizeof(expected_reset)/sizeof(expected_reset[0]));
 for(k=0;k<2;++k){
  count=0;now=10;busy=1;p.io=&io;p.context=0;p.component=1;p.state=NEBULAR_REFRESH_WAIT;p.since=0;
  assert(nebular_poll(&p)==NEBULAR_OFF_WAIT);assert(count==6);now+=1;
  if(k){busy=0;assert(nebular_poll(&p)==NEBULAR_OFF_WAIT);assert(count==6);now+=137;busy=1;}
  assert(nebular_poll(&p)==NEBULAR_DONE);
  compare(1,expected_shutdown,sizeof(expected_shutdown)/sizeof(expected_shutdown[0]));
  assert(count==11 && events[10].kind==1 && events[10].value==0);
 }
 puts("PASS: power/reset and normal shutdown match source-checked stock traces; sleep waits 1ms after immediate and delayed BUSY release.");return 0;
}
