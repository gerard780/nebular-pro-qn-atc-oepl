#!/usr/bin/env python3
"""Check final binary patch boundaries and integration without hardware."""
import hashlib,json,struct,zlib
from pathlib import Path
P=Path(__file__).resolve().parent
base=(P/'inputs/ATC_BLE_OEPL-reference.bin').read_bytes()
meta=json.loads((P/'dist/manifest.json').read_text());image=(P/'dist'/meta['firmware']).read_bytes()
symbols=json.loads((P/'symbols.json').read_text());hooks=json.loads((P/'inputs/hooks.json').read_text())
assert hashlib.sha256(image).hexdigest()==meta['sha256'] and len(image)==meta['bytes']<0x20000
assert struct.unpack_from('<I',image,24)[0]==len(image)
assert struct.unpack_from('<I',image,len(image)-4)[0]==(zlib.crc32(image[:-4])^0xffffffff)
allowed=[(24,28),(0x6260,0x6260+meta['core_bytes']),(0xc896,0xc89a),(len(base)-4,len(base))]
for addr,hook in hooks.items():
 off=int(addr,16);allowed.append((off,off+8))
 assert image[off:off+8]==struct.pack('<HHI',0x0b00,0x0718,symbols[hook['symbol']]|1)
delta=symbols['nebular_boot']-0xc896-4
assert image[0xc896:0xc89a]==struct.pack('<HH',0x9000|((delta>>12)&0x7ff),0x9800|((delta>>1)&0x7ff))
assert image[0x6260:0x6260+meta['core_bytes']]==(P/'core.bin').read_bytes()
assert image[0x1c900:0x1c900+meta['payload_bytes']]==(P/'payload.bin').read_bytes()
off=0x1b188+17*42
allowed.extend([(off,off+2),(off+7,off+11),(off+25,off+33)])
assert struct.unpack_from('<H',image,off)[0]==0x74
assert struct.unpack_from('<H',image,off+2)[0]==5
assert struct.unpack_from('<HH',image,off+7)==(480,176)
assert image[off+25:off+33]==bytes(8)
assert image[off+21:off+25]==base[off+21:off+25] # retained EPD GPIO pointer
assert image[0x1b188:0x1b188+42]==base[0x1b188:0x1b188+42] # unknown-model preset0
for i,(a,b) in enumerate(zip(base,image)):
 if a!=b: assert any(start<=i<end for start,end in allowed),hex(i)
assert image[len(base):0x1c900]==b'\xff'*(0x1c900-len(base))
profile=json.loads((P/'dist/74.json').read_text())
assert (profile['width'],profile['height'],profile['rotatebuffer'],profile['bpp'])==(480,176,1,2)
assert not profile.get('zlib_compression') and not profile.get('g5_compression') and not profile['options']
result=dict(firmware_sha256=meta['sha256'],firmware_bytes=len(image),source_sha256=meta['stock_sha256'],
            initialization_cases=16,paired_refresh_cases=24,image_pixel_checks=84480,product_record_mutations=92,
            temperature_values_checked=256,busy_timeout_paths=5,lifecycle_source_trace_comparisons=["power/reset","normal shutdown"],power_off_busy_cases=["immediate","delayed"],base_patch_boundaries_verified=True,
            application_only=True,hardware_access=False,physical_display_validation=False)
(P/'dist/verification.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: final binary header/CRC, exact hook targets, allowed patch boundaries, preserved EPD pins, disabled LED/NFC, disabled unknown preset and uncompressed AP profile.')
